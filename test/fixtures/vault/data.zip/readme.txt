A zip file, shown as a generic file card.
